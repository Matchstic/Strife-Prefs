Strife preferences
==================

Yeah, I know this is all a mess; it'll get sorted out someday. Still, source for all of this is over at https://github.com/matchstic-dev/Strife-Prefs/

Enjoy!